# Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddressLineOne** | **string** | AddressLineOne | [optional] 
**AddressLineTwo** | **string** | AddressLineTwo | [optional] 
**AddressLineThree** | **string** | AddressLineThree | [optional] 

