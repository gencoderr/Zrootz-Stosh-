# TimeHHMM

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ReceiptTime** | **string** | ReceiptTime  HHMM, based on a 24-hour clock, Eastern Time  | [optional] 

