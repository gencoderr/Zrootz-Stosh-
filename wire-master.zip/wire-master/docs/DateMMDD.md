# DateMMDD

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Date** | **string** | Date  MMDD, based on the calendar date  | [optional] 
