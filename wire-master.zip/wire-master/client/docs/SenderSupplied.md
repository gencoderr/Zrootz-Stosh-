# SenderSupplied

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FormatVersion** | **string** | FormatVersion 30  | 
**UserRequestCorrelation** | **string** | UserRequestCorrelation | 
**TestProductionCode** | **string** | Identifies if test or production.  * &#x60;T&#x60; - Test * &#x60;P&#x60; - Production  | 
**MessageDuplicationCode** | **string** | MessageDuplicationCode  * &#x60; &#x60; - Original Message * &#x60;R&#x60; - Retrieval of an original message * &#x60;P&#x60; - Resend  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


