# ErrorWire

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ErrorCategory** | **string** | ErrorCategory * &#x60;E&#x60; - Data Error * &#x60;F&#x60; - Insufficient Balance * &#x60;H&#x60; - Accountability Error * &#x60;I&#x60; - In Process or Intercepted * &#x60;W&#x60; - Cutoff Hour Error * &#x60;X&#x60; - Duplicate IMAD  | [optional] 
**ErrorCode** | **string** | ErrorCode | [optional] 
**ErrorDescription** | **string** | ErrorDescription | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


