# ServiceMessage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LineOne** | **string** | LineOne | [optional] 
**LineTwo** | **string** | LineTwo | [optional] 
**LineThree** | **string** | LineThree | [optional] 
**LineFour** | **string** | LineFour | [optional] 
**LineFive** | **string** | LineFive | [optional] 
**LineSix** | **string** | LineSix | [optional] 
**LineSeven** | **string** | LineSeven | [optional] 
**LineEight** | **string** | LineEight | [optional] 
**LineNine** | **string** | LineNine | [optional] 
**LineTen** | **string** | LineTen | [optional] 
**LineEleven** | **string** | LineEleven | [optional] 
**LineTwelve** | **string** | LineTwelve | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


