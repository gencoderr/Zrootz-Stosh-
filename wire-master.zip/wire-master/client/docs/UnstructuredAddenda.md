# UnstructuredAddenda

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddendaLength** | **string** | AddendaLength  Addenda Length must be numeric, padded with leading zeros if less than four characters, and must equal length of content in Addenda Information (e.g., if content of Addenda Information is 987 characters, Addenda Length must be 0987).  | [optional] 
**Addenda** | **string** | Addenda | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


