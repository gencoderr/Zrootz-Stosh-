# CoverPayment

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SwiftFieldTag** | **string** | SwiftFieldTag | [optional] 
**SwiftLineOne** | **string** | SwiftLineOne | [optional] 
**SwiftLineTwo** | **string** | SwiftLineTwo | [optional] 
**SwiftLineThree** | **string** | SwiftLineThree | [optional] 
**SwiftLineFour** | **string** | SwiftLineFour | [optional] 
**SwiftLineFive** | **string** | SwiftLineFive | [optional] 
**SwiftLineSix** | **string** | SwiftLineSix | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


