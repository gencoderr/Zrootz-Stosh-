# WireAmount

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Amount** | **string** | Amount is 12 numeric digits, right-justified with leading zeros. It has an implied decimal point and no commas (e.g., $12,345.67 becomes 000001234567). Can be all zeros for subtype 90.  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


