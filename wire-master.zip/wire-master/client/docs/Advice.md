# Advice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdviceCode** | **string** | Advice Code  * &#x60;HLD&#x60; - Hold * &#x60;LTR&#x60; - Letter * &#x60;PHN&#x60; - Phone * &#x60;TLX&#x60; - Telex * &#x60;WRE&#x60; - Wire  | [optional] 
**LineOne** | **string** | LineOne | [optional] 
**LineTwo** | **string** | LineTwo | [optional] 
**LineThree** | **string** | LineThree | [optional] 
**LineFour** | **string** | LineFour | [optional] 
**LineFive** | **string** | LineFive | [optional] 
**LineSix** | **string** | LineSix | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


