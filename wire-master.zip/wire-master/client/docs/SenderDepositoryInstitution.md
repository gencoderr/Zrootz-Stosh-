# SenderDepositoryInstitution

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SenderABANumber** | **string** | SenderABANumber | 
**SenderShortName** | **string** | SenderShortName | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


