# ValidateOptions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SkipMandatoryIMAD** | **bool** | Skip validation of the InputMessageAccountabilityData (IMAD) field | [optional] [default to false]
**AllowMissingSenderSupplied** | **bool** | Allow FedWireMessage.SenderSupplied to be nil | [optional] [default to false]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


