# DateRemittanceDocument

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DateRemittanceDocument** | **string** | DateRemittanceDocument (Format CCYYMMDD - C&#x3D;Century, Y&#x3D;Year, M&#x3D;Month, D&#x3D;Day) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


