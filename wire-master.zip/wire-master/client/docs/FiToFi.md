# FiToFi

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LineOne** | **string** | LineOne | [optional] 
**LineTwo** | **string** | LineTwo | [optional] 
**LineThree** | **string** | LineThree | [optional] 
**LineFour** | **string** | LineFour | [optional] 
**LineFive** | **string** | LineFive | [optional] 
**LineSix** | **string** | LineSix | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


