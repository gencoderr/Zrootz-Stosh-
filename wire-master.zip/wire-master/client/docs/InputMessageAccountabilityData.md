# InputMessageAccountabilityData

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InputCycleDate** | **string** | InputCycleDate (Format CCYYMMDD - C&#x3D;Century, Y&#x3D;Year, M&#x3D;Month, D&#x3D;Day)  | 
**InputSource** | **string** | InputSource | 
**InputSequenceNumber** | **string** | InputSequenceNumber | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


