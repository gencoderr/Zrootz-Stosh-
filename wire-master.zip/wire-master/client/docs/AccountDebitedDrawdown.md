# AccountDebitedDrawdown

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdentificationCode** | **string** | Identification Code * &#x60;D&#x60; - Debit  | 
**Identifier** | **string** | Identifier | 
**Name** | **string** | Name | 
**AddressLineOne** | **string** | AddressLineOne | [optional] 
**AddressLineTwo** | **string** | AddressLineTwo | [optional] 
**AddressLineThree** | **string** | AddressLineThree | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


